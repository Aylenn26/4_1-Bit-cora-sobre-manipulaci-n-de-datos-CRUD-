package edu.itvo.roompersistence.domain.usecase

import edu.itvo.roompersistence.domain.model.Stadium
import edu.itvo.roompersistence.domain.repository.StadiumRepository
import javax.inject.Inject

/*
=================================================
ADD STADIUM USE CASE
=================================================

Caso de uso encargado de agregar un estadio
a la base de datos.

Actúa como intermediario entre el ViewModel
y el Repository.
*/

class AddStadiumUseCase @Inject constructor(

    private val repository: StadiumRepository

) {

    /*
    Ejecuta la acción de insertar un estadio.
    Se usa operator fun invoke para llamarlo
    como una función normal.
    */
    suspend operator fun invoke(
        stadium: Stadium
    ) {
        repository.insertStadium(stadium)
    }
}