package edu.itvo.roompersistence.domain.usecase

import edu.itvo.roompersistence.domain.repository.StadiumRepository
import javax.inject.Inject

/*
=================================================
GET STADIUMS USE CASE
=================================================

Caso de uso encargado de obtener la lista
de estadios desde el repositorio.
*/

class GetStadiumsUseCase @Inject constructor(

    private val repository: StadiumRepository

) {

    /*
    Retorna la lista de estadios como Flow,
    permitiendo actualización en tiempo real.
    */
    operator fun invoke() =
        repository.getStadiums()
}