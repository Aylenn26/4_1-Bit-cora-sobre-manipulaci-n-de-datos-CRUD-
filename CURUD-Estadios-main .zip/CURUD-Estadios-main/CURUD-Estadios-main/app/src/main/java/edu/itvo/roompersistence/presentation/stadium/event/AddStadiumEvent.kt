package edu.itvo.roompersistence.presentation.stadium.event


sealed interface AddStadiumEvent {

    /*
    Evento cuando cambia el nombre del estadio
    */
    data class OnNameChanged(
        val value: String
    ) : AddStadiumEvent

    /*
    Evento cuando cambia la ciudad
    */
    data class OnCityChanged(
        val value: String
    ) : AddStadiumEvent

    /*
    Evento cuando cambia el país
    */
    data class OnCountryChanged(
        val value: String
    ) : AddStadiumEvent

    /*
    Evento cuando cambia la capacidad
    */
    data class OnCapacityChanged(
        val value: String
    ) : AddStadiumEvent

    /*
    Evento cuando se selecciona una foto
    */
    data class OnPhotoSelected(
        val value: String
    ) : AddStadiumEvent

    /*
    Evento para guardar el estadio
    */
    data object SaveStadium : AddStadiumEvent
}