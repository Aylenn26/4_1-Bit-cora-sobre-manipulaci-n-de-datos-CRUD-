package edu.itvo.roompersistence.data.repository

import edu.itvo.roompersistence.data.local.dao.StadiumDao
import edu.itvo.roompersistence.data.mapper.toDomain
import edu.itvo.roompersistence.data.mapper.toEntity
import edu.itvo.roompersistence.domain.model.Stadium
import edu.itvo.roompersistence.domain.repository.StadiumRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

/*
=================================================
STADIUM REPOSITORY IMPLEMENTATION
=================================================

Esta clase implementa la interfaz StadiumRepository.

Su función es servir como puente entre la capa
Domain y la capa Data.

Aquí se realiza la comunicación con Room mediante
StadiumDao y se convierten los datos entre:

- Stadium (modelo de dominio)
- StadiumEntity (entidad de base de datos)

También utiliza Hilt para la inyección de
dependencias mediante @Inject.
*/

class StadiumRepositoryImpl @Inject constructor(

    /*
    StadiumDao es inyectado automáticamente por Hilt.

    Este DAO contiene las operaciones que se ejecutan
    directamente sobre la base de datos Room.
    */
    private val stadiumDao: StadiumDao

) : StadiumRepository {

    /*
    =========================================
    INSERT STADIUM
    =========================================

    Guarda un nuevo estadio en la base de datos.

    Primero convierte el objeto Stadium
    (modelo de dominio) a StadiumEntity
    (entidad de Room) mediante toEntity().

    Después lo envía al DAO para ser almacenado.
    */
    override suspend fun insertStadium(
        stadium: Stadium
    ) {

        stadiumDao.insertStadium(
            stadium.toEntity()
        )
    }

    /*
    =========================================
    GET STADIUMS
    =========================================

    Obtiene todos los estadios almacenados.

    El DAO devuelve una lista de StadiumEntity.

    Luego se utiliza map para transformar cada
    StadiumEntity en un objeto Stadium usando
    la función toDomain().

    Finalmente retorna:
    Flow<List<Stadium>>

    Esto permite que la interfaz se actualice
    automáticamente cuando existan cambios en
    la base de datos.
    */
    override fun getStadiums(): Flow<List<Stadium>> {

        return stadiumDao.getStadiums()
            .map { entities ->

                entities.map { entity ->

                    entity.toDomain()

                }
            }
    }

    /*
    =========================================
    DELETE STADIUM
    =========================================

    Elimina un estadio de la base de datos.

    Primero convierte Stadium a StadiumEntity
    mediante toEntity().

    Después envía el objeto al DAO para que
    sea eliminado.
    */
    override suspend fun deleteStadium(
        stadium: Stadium
    ) {

        stadiumDao.deleteStadium(
            stadium.toEntity()
        )
    }

    /*
    =========================================
    GET STADIUM BY ID
    =========================================

    Busca un estadio específico utilizando su ID.

    El DAO devuelve un StadiumEntity o null.

    Si existe un registro:
        StadiumEntity -> Stadium

    mediante la función toDomain().

    Si no existe:
        retorna null.

    Esta función es utilizada principalmente
    para la funcionalidad de edición de estadios.
    */
    override suspend fun getStadiumById(
        id: Long
    ): Stadium? {

        return stadiumDao
            .getStadiumById(id)
            ?.toDomain()
    }
}