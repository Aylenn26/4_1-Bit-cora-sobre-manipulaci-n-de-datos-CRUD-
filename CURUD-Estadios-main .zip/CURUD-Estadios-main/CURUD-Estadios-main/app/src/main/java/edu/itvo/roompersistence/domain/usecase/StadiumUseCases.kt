package edu.itvo.roompersistence.domain.usecase

/*
=================================================
STADIUM USE CASES
=================================================

Esta clase agrupa todos los casos de uso (Use Cases)
relacionados con Stadium.

Su función principal es facilitar la inyección de
dependencias y permitir que el ViewModel tenga acceso
a todas las operaciones del CRUD desde un solo objeto.

*/

data class StadiumUseCases(

    /*
    Caso de uso encargado de agregar un estadio
    a la base de datos.
    */
    val addStadium: AddStadiumUseCase,

    /*
    Caso de uso encargado de obtener la lista
    de todos los estadios registrados.
    */
    val getStadiums: GetStadiumsUseCase,

    /*
    Caso de uso encargado de eliminar un estadio
    existente en la base de datos.
    */
    val deleteStadium: DeleteStadiumUseCase
)