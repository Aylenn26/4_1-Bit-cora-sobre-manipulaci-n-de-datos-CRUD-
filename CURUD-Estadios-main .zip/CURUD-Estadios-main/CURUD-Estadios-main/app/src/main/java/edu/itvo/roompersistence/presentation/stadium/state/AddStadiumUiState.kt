package edu.itvo.roompersistence.presentation.stadium.state

/*
=================================================
ADD STADIUM UI STATE
=================================================

Este State representa el estado de la pantalla
de agregar/editar estadio.

Contiene todos los datos que la UI necesita
mostrar o modificar.
*/

data class AddStadiumUiState(

    /*
    ID del estadio (0 si es nuevo registro)
    */
    val id: Long = 0,

    /*
    Nombre del estadio
    */
    val name: String = "",

    /*
    Ciudad del estadio
    */
    val city: String = "",

    /*
    País del estadio
    */
    val country: String = "",

    /*
    Capacidad del estadio (se maneja como String
    para facilitar el TextField, luego se convierte
    a Int en el ViewModel)
    */
    val capacity: String = "",

    /*
    URI de la imagen seleccionada
    */
    val photoUri: String? = null,

    /*
    Indica si la pantalla está cargando datos
    */
    val isLoading: Boolean = false,

    /*
    Mensaje de error si algo falla
    */
    val errorMessage: String? = null
)